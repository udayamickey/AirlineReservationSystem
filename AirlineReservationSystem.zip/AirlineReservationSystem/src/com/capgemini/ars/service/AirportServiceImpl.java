package com.capgemini.ars.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.ars.bean.AirportBean;
import com.capgemini.ars.dao.AirportDaoImpl;
import com.capgemini.ars.dao.IAirportDao;
import com.capgemini.ars.exception.ARSException;

public class AirportServiceImpl implements IairportService{
IAirportDao airportDAO=new AirportDaoImpl();
	@Override
	public List<AirportBean> getAirportNames() throws ARSException {
		List<AirportBean> airportList = new ArrayList<>();
		airportList=airportDAO.getAirportNames();
		return airportList;
	}
	@Override
	public Integer addAirport(AirportBean airport) throws ARSException {
		
		return airportDAO.addAirport(airport);
	}

}
