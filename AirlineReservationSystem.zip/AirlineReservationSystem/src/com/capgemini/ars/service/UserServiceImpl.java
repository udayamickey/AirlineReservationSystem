package com.capgemini.ars.service;

import com.capgemini.ars.bean.UserBean;
import com.capgemini.ars.dao.IUserDao;
import com.capgemini.ars.dao.UserDaoImpl;
import com.capgemini.ars.exception.ARSException;

public class UserServiceImpl implements IUserService{
	IUserDao userDAO = new UserDaoImpl();
	@Override
	public Integer addUserDetails(UserBean user) throws ARSException {
		return userDAO.addUserDetails(user);
		
	}

	@Override
	public UserBean getUserDetails(String username) throws ARSException {
		UserBean user = new UserBean();
		user = userDAO.getUserDetails(username);
		return user;
	}

	@Override
	public boolean isValidUser(String username, String password)
			throws ARSException {
		boolean bool=userDAO.isValidUser(username, password);
		return bool;
	}

	@Override
	public String getUserRole(String username, String password)
			throws ARSException {
		String role = userDAO.getUserRole(username, password);
		return role;
	}

}
