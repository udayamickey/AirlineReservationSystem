package com.capgemini.ars.bean;

public class UserBean {
	private String userName;
	private String password;
	private Long mobileNo;
	private String emailId;
	private String role;
	public static final String USER="USER";
	public static final String ADMIN="ADMIN";
	public static final String EXECUTIVE="AIRLINE_EXECUTIVE";
	public UserBean() {
		super();
	}
	
	public UserBean(String userName) {
		super();
		this.userName = userName;
	}

	public UserBean(String userName, String password, Long mobileNo, String role) {
		super();
		this.userName = userName;
		this.password = password;
		this.mobileNo = mobileNo;
		this.role = role;
	}

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String[] getUserRoles(){
		return new String[]{USER,ADMIN,EXECUTIVE};
	}
	@Override
	public String toString() {
		return "UserBean [userName=" + userName + ", password=" + password
				+ ", mobileNo=" + mobileNo + ", emailId=" + emailId + ", role="
				+ role + "]";
	}
	
	
}
