package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.ars.bean.BookingBean;
import com.capgemini.ars.exception.ARSException;
import com.capgemini.ars.utility.DBConnection;



public class BookingDaoImpl implements IBookingDao{


	private static Logger bookingLogger=Logger.getLogger(BookingDaoImpl.class);

	@Override
	public BookingBean addBookingDetails(String custEmail,Integer noOfPassengers,String classType,String creditCardInfo,String srcCity,String destCity,Double totalfare,String flightno) throws ARSException {
		try(Connection connection =DBConnection.getConnection();
				PreparedStatement pstmt=connection.prepareStatement
						("insert into bookinginfodummy(Booking_id, cust_email, no_of_passengers, class_type,total_fare, CreditCard_info, src_city, dest_city) "
								+ "values(booking_id_sequence.NEXTVAL,?,?,?,?,?,?,?)");
				PreparedStatement pstmt1=connection.prepareStatement
						("insert into bookinginfo(Booking_id, cust_email, no_of_passengers, class_type,total_fare, seat_number,CreditCard_info, src_city, dest_city,flightno)"
								+ " values(?,?,?,?,?,?,?,?,?,?)");		
				PreparedStatement pstmt2=connection.prepareStatement("select booking_id from bookinginfodummy where cust_email=?");
				PreparedStatement stmt=connection.prepareStatement("select firstclass_seat_number_seq.NEXTVAL from dual");	
				PreparedStatement stmt1=connection.prepareStatement("select busseats_seat_number_seq.NEXTVAL from dual");	
				Statement stamt = connection.createStatement();
				){
			pstmt.setString(1, custEmail);
			pstmt.setInt(2, noOfPassengers);
			pstmt.setString(3, classType);
			pstmt.setDouble(4, totalfare);
			pstmt.setString(5, creditCardInfo);
			pstmt.setString(6, srcCity);
			pstmt.setString(7, destCity);
			ResultSet rss=pstmt.executeQuery();
			
			int bookingCount=0;
			if(rss.next()){
				
				pstmt2.setString(1, custEmail);
				ResultSet resultSet=pstmt2.executeQuery();
				
				if(resultSet.next()){
					Integer bId=resultSet.getInt(1);
					
					bookingCount++;
					BookingBean booking=new BookingBean();
					booking =seatNumber(custEmail, noOfPassengers, classType,
							creditCardInfo, srcCity, destCity, totalfare,
							pstmt1, stmt, bId, booking,flightno);
					
					return booking;
				}
			}
		}catch(SQLException e){


			bookingLogger.error("unable to add booking details for this user");
		}
		return null;

	}

	private BookingBean seatNumber(String custEmail, Integer noOfPassengers,
			String classType, String creditCardInfo, String srcCity,
			String destCity, Double totalfare, PreparedStatement pstmt1,
			PreparedStatement stmt, Integer bId, BookingBean booking,String flightno)
			throws SQLException, ARSException {
		try(Connection con=DBConnection.getConnection();
				Statement st=con.createStatement();
				PreparedStatement pst=con.prepareStatement("select * from bookinginfo where booking_id=?")){
		if(classType.equalsIgnoreCase("FIRSTCLASS")){
			
			ResultSet rs=st.executeQuery("select firstclass_seat_number_seq.NEXTVAL from dual");
			if(rs.next()){
				Integer firstSeatNumber=rs.getInt(1);
			
			
			pstmt1.setInt(1, bId);
			pstmt1.setString(2,custEmail);
			pstmt1.setInt(3,noOfPassengers);
			pstmt1.setString(4,classType);
			pstmt1.setDouble(5,totalfare);
			pstmt1.setInt(6,firstSeatNumber);
			pstmt1.setString(7,creditCardInfo);
			pstmt1.setString(8, srcCity);
			pstmt1.setString(9, destCity);
			pstmt1.setString(10, flightno);
			int n=pstmt1.executeUpdate();
			
			if(n!=0){
				pst.setInt(1, bId);
				ResultSet rs1=pst.executeQuery();
				
				populateBooking(booking,rs1);
				
				return booking;
			}
			}
		}
		else if(classType.equalsIgnoreCase("BUSSCLASS")){
			ResultSet rs=st.executeQuery("select busseats_seat_number_seq.NEXTVAL from dual");
			if(rs.next()){
			Integer busSeatNumber=rs.getInt(1);
			
			pstmt1.setInt(1, bId);
			pstmt1.setString(2,custEmail);
			pstmt1.setInt(3,noOfPassengers);
			pstmt1.setString(4,classType);
			pstmt1.setDouble(5,totalfare);
			pstmt1.setInt(6,busSeatNumber);
			pstmt1.setString(7,creditCardInfo);
			pstmt1.setString(8, srcCity);
			pstmt1.setString(9, destCity);
			pstmt1.setString(10, flightno);
			int n=pstmt1.executeUpdate();
			if(n!=0){
				pst.setInt(1, bId);
				ResultSet rs1=pst.executeQuery();

				

				populateBooking(booking,rs1);
				
				return booking;
			}
		}else{

		}
		}
		}catch(SQLException e){
			
		}
		return null;
	}

	private void populateBooking(BookingBean booking, ResultSet resultSet) throws SQLException {
		if(resultSet.next()){

		booking.setBookingId(resultSet.getInt("booking_id"));
		booking.setCustEmail(resultSet.getString("cust_email"));
		booking.setNoOfPassengers(resultSet.getInt("no_of_passengers"));
		booking.setClassType(resultSet.getString("class_type"));
		booking.setTotalFare(resultSet.getDouble("total_fare"));
		booking.setSeatNo(resultSet.getInt("seat_number"));
		booking.setCreditCardInfo(resultSet.getString("creditcard_info"));
		booking.setSrcCity(resultSet.getString("src_city"));
		booking.setDestCity(resultSet.getString("dest_city"));
		booking.setFlightno(resultSet.getString("flightno"));
		}


	}

	@Override
	public Integer deleteBookingDetails(Integer bookingId)throws ARSException {
		
		try(   
				Connection connection=DBConnection.getConnection();
				PreparedStatement ps2=connection.prepareStatement("delete from bookinginfo where booking_id=?");
				Statement statement = connection.createStatement();

				){
			
			ps2.setInt(1, bookingId);
			int n=ps2.executeUpdate();
			
			if(n!=0) {
				
				bookingLogger.info("your corresponding booking info deleted");
				return n;
			}else {
			
				return null;
			}
		}catch(SQLException e){
			e.printStackTrace();
			bookingLogger.error("unable to cancel your booking");
			
			throw new ARSException("Technical Error. Refer to log");

		}


	}

	@Override
	public List<BookingBean> retrieveAllBookingDetails() throws ARSException {
		String sql="select * from bookinginfo";
		int bookingcount=0;
		try(   
				Connection connection=DBConnection.getConnection();
				Statement statement = connection.createStatement();
				){
			ResultSet resultSet=statement.executeQuery(sql);

			List<BookingBean> bookingList=new ArrayList<>();
			while(resultSet.next()){
				bookingcount++;
				BookingBean booking=new BookingBean();
				try{
					populateBookings(booking,resultSet);
				}catch(SQLException e){

				}
				bookingList.add(booking);
			}
			if(bookingcount!=0){
				bookingLogger.info("your booking details retrieved");
				return bookingList;
			}
			else{
				return null;
			}
		}catch(SQLException e){
			bookingLogger.error("unable to retreieve booking details");
			//e.printStackTrace();
		}


		return null;
	}

	private void populateBookings(BookingBean booking, ResultSet resultSet) throws SQLException{
		try {
			//if(resultSet.next()){
			booking.setBookingId(resultSet.getInt("booking_id"));
			booking.setCustEmail(resultSet.getString("cust_email"));
			booking.setNoOfPassengers(resultSet.getInt("no_of_passengers"));
			booking.setClassType(resultSet.getString("class_type"));
			booking.setSeatNo(resultSet.getInt("seat_number"));
			booking.setTotalFare(resultSet.getDouble("total_fare"));
			booking.setCreditCardInfo(resultSet.getString("creditcard_info"));
			booking.setSrcCity(resultSet.getString("src_city"));
			booking.setDestCity(resultSet.getString("dest_city"));
			booking.setFlightno(resultSet.getString("flightno"));
			//}
		} catch (Exception e) {
		
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}

	}

	@Override
	public List<BookingBean> getBookingDetails(String custEmail) throws ARSException {
		String sql="select * from bookinginfo where cust_email=?";
		int bookingcount=0;
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement statement = connection.prepareStatement(sql);

				){
			statement.setString(1, custEmail);
			ResultSet resultSet=statement.executeQuery();

			List<BookingBean> bookingList=new ArrayList<>();
			while(resultSet.next()){
				bookingcount++;
				BookingBean booking=new BookingBean();
				populateBookings(booking,resultSet);
				bookingList.add(booking);
			}
			if(bookingcount!=0){
				bookingLogger.info("Booking details retreieved for this correspoding email id");
				return bookingList;
			}
			else{
				return null;
			}


		}catch(SQLException e){
			bookingLogger.error("unable to fetch booking details for this mail");
			//e.printStackTrace();
		}

		return null;
	}

	@Override
	public Integer updateEmail(String Email,Integer bookingId) throws ARSException {
		String sql="update bookinginfo set cust_email=? where booking_id=?";
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement statement=connection.prepareStatement(sql)){
			statement.setString(1, Email);
			statement.setInt(2, bookingId);

			int n=statement.executeUpdate();
			if(n>0){
			
			bookingLogger.info("Booking information updated succesfully");
			
			return n;
			}
		}catch(SQLException e){
			bookingLogger.error("unable to update booking information");
			//e.printStackTrace();
		}
		return null;

	}
	@Override
	public List<BookingBean> viewPassengerList(String flightno)
			throws ARSException {
		int bookCount=0;
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from bookinginfo where flightno=?")
						){
			preparedStatement.setString(1, flightno);
			ResultSet resultSet= preparedStatement.executeQuery();
			List<BookingBean> bookingList=new ArrayList<>();
			while(resultSet.next()){
				bookCount++;
				BookingBean booking=new BookingBean();
				populateBookings(booking,resultSet);
				bookingList.add(booking);
			}
			if(bookCount!=0){
				bookingLogger.info("booking information gathered for this flight number");
				return bookingList;
			}		
		}catch(SQLException e){
			bookingLogger.error("No booking information for this flight number");
			//e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean getBookingIdList(Integer Id) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from bookinginfo where booking_id=?")
				
				){
			preparedStatement.setInt(1,Id);
			ResultSet rs= preparedStatement.executeQuery();
			if(rs.next()){
				bookingLogger.info("booking details retreived for this booking id");
				return true;
			}		}catch(SQLException e){
				bookingLogger.error("no booking details found for this booking id");
			}
			
		return false;
	}

	@Override
	public List<BookingBean> viewYourBooking(Integer BookingId)
			throws ARSException {
		String sql="select * from bookinginfo where booking_id=?";
		int bookingcount=0;
		try(
				Connection connection=DBConnection.getConnection();
				PreparedStatement statement = connection.prepareStatement(sql);

				){
			statement.setInt(1, BookingId);
			ResultSet resultSet=statement.executeQuery();

			List<BookingBean> bookingList=new ArrayList<>();
			while(resultSet.next()){
				bookingcount++;
				BookingBean booking=new BookingBean();
				populateBookings(booking,resultSet);
				bookingList.add(booking);
			}
			if(bookingcount!=0){
				bookingLogger.info("booking information gathered for this booking id");
				return bookingList;
			}
			else{
				return null;
			}


		}catch(SQLException e){
			bookingLogger.error("no corresponding booking information for this booking id");
			//e.printStackTrace();
		}

		return null;
	}


}

