package com.capgemini.ars.dao;



import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.ars.bean.FlightBean;
import com.capgemini.ars.exception.ARSException;
import com.capgemini.ars.utility.DBConnection;

public class FlightDaoImpl implements IFlightDao{
	private static Logger myFlightLogger=Logger.getLogger(FlightDaoImpl.class);

	@Override
	public void addFlight(FlightBean flight) throws ARSException {
		try(
				Connection connection =DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement("insert into FlightInfo values(?,?,?,?,?,?,?,?,?,?,?,?)")){
			preparedStatement.setString(1, flight.getFlightNo());
			preparedStatement.setString(2, flight.getAirline());
			preparedStatement.setString(3, flight.getDep_city());
			preparedStatement.setString(4, flight.getArr_city());
			preparedStatement.setDate(5, flight.getDep_date());
			preparedStatement.setDate(6, flight.getArr_date());
			preparedStatement.setString(7,flight.getDep_time());
			preparedStatement.setString(8, flight.getArr_time());
			preparedStatement.setInt(9, flight.getFirstSeats());
			preparedStatement.setDouble(10,flight.getBussSeatFare());
			preparedStatement.setInt(11,flight.getBussSeats());
			preparedStatement.setDouble(12, flight.getBussSeatFare());
			int n=preparedStatement.executeUpdate();
			if(n!=0){
				//System.out.println("Flight added");
				myFlightLogger.info("flight added");
			}

		}catch(SQLException e)
		{
			myFlightLogger.error("Unable to add flight");
			//e.printStackTrace();
		}

	}

	@Override
	public Integer deleteFlight(String flightNo) throws ARSException {
		try(
				Connection connection =DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement("delete from FlightInfo where flightno=?")){
			preparedStatement.setString(1, flightNo);
			int n=preparedStatement.executeUpdate();
			if(n!=0){
				myFlightLogger.info("flight deleted");

				return n;
			}



		}catch(SQLException e){
			myFlightLogger.error("Unable to delete flight");

			//e.printStackTrace();
		}
		return null;
	}

	@Override
	public Integer updateFlight(String fno,String dtime,String atime) throws ARSException {
		try(Connection connection =DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement("update FlightInfo set dep_time=?,arr_time=? where flightno=?");){
			preparedStatement.setString(1,dtime);
			preparedStatement.setString(2,atime);
			preparedStatement.setString(3,fno);

			int n=preparedStatement.executeUpdate();
			if(n!=0){
				myFlightLogger.info("Flight updated with your specifications ");

				return n;
			}

		}catch(SQLException e){
			myFlightLogger.error("Unable to update flight");

			//e.printStackTrace();
		}
		return 0;
	}

	@Override
	public List<FlightBean> getAllFlightDetails() throws ARSException {
		int flightCount=0;
		try(
				Connection connection=DBConnection.getConnection();	
				Statement statement=connection.createStatement();
				){
			ResultSet resultSet = statement.executeQuery("select * from FlightInfo");
			List<FlightBean> flightList = new ArrayList<>();
			while(resultSet.next()){
				flightCount++;
				
				//if(resultSet.next()){
					FlightBean flight = new FlightBean();
					populateFlight(flight,resultSet);
					flightList.add(flight);
			//	}
			}
			if(flightCount!=0){
				myFlightLogger.info("Flight details retreived succesfully ");

				return flightList;
			}else{
				

				return null;
			}

		}catch(SQLException e){
			myFlightLogger.error("Unable to retreive flight details");
			throw new ARSException("Technical Error! Refer to log");

		}

	}

	private void populateFlight(FlightBean flight, ResultSet resultSet) throws SQLException {

		flight.setFlightNo(resultSet.getString("flightno"));
		flight.setAirline(resultSet.getString("airline"));
		flight.setDep_city(resultSet.getString("dep_city"));
		flight.setArr_city(resultSet.getString("arr_city"));
		flight.setDep_date(resultSet.getDate("dep_date"));
		flight.setArr_date(resultSet.getDate("arr_date"));
		flight.setDep_time(resultSet.getString("dep_time"));
		flight.setArr_time(resultSet.getString("arr_time"));
		flight.setFirstSeats(resultSet.getInt("firstseats"));
		flight.setFirstSeatFare(resultSet.getDouble("firstseatfare"));
		flight.setBussSeats(resultSet.getInt("bussseats"));
		flight.setBussSeatFare(resultSet.getDouble("bussseatsfare"));


	}

	@Override
	public List<FlightBean> getFlights(String dep_city, String arr_city,
			Date dep_date) throws ARSException {
		int flightCount=0;
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from FlightInfo where dep_city=? and arr_city=? and dep_date=?")



				){
			preparedStatement.setString(1, dep_city);
			preparedStatement.setString(2, arr_city);
			preparedStatement.setDate(3, dep_date);

			ResultSet resultSet=preparedStatement.executeQuery();
			List<FlightBean> flightList = new ArrayList<>();
			while(resultSet.next()){
				flightCount++;
				FlightBean flight = new FlightBean();

				populateFlight(flight,resultSet);
				flightList.add(flight);
			}
			if(flightCount!=0){
				myFlightLogger.info("fight details retrieved with your specifications");
				return flightList;
			}else{
				return null;
			}


		}catch(SQLException e){

			myFlightLogger.error("No flights found with your specifications");
		}
		return null;
	}

	@Override
	public FlightBean getFlightDetails(String flightno) throws ARSException {
		try(
				Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from FlightInfo where flightno=?")){
			preparedStatement.setString(1, flightno);
			FlightBean flight=new FlightBean();
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){
				flight.setFlightNo(flightno);
				flight.setAirline(resultSet.getString(2));
				flight.setDep_city(resultSet.getString(3));
				flight.setArr_city(resultSet.getString(4));
				flight.setDep_date(resultSet.getDate(5));
				flight.setArr_date(resultSet.getDate(6));
				flight.setDep_time(resultSet.getString(7));
				flight.setArr_time(resultSet.getString(8));
				flight.setFirstSeats(resultSet.getInt(9));
				flight.setFirstSeatFare(resultSet.getDouble(10));
				flight.setBussSeats(resultSet.getInt(11));
				flight.setBussSeatFare(resultSet.getDouble(12));
				return flight;
			}
		}catch(SQLException e){

			myFlightLogger.error("no flight found with this flight no");

		}
		return null;
	}

	@Override
	public Integer getFirstSeatOccupancy(String flightno) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
						("select firstseats from FlightInfo where flightno=?")){
			preparedStatement.setString(1,flightno);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				Integer firstSeatAvailability=resultSet.getInt(1);
				return firstSeatAvailability;

			}


		}catch(SQLException e){
			myFlightLogger.error("limit exceeded");
		}
		return null;
	}

	@Override
	public Integer getBussSeatOccupancy(String flightno) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement
						("select bussseats from FlightInfo where flightno=?")){
			preparedStatement.setString(1,flightno);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next()){
				Integer bussSeatAvailability=resultSet.getInt(1);
				return bussSeatAvailability;

			}


		}catch(SQLException e){
			myFlightLogger.error("limit exceded");
		}
		return null;
	}

	@Override
	public boolean isValidFlightNo(String dep_city, String arr_city,
			Date dep_date, String flightno) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from FlightInfo where dep_city=? and arr_city=? and dep_date=? and flightno=?")){
			preparedStatement.setString(1,dep_city );
			preparedStatement.setString(2,arr_city );
			preparedStatement.setDate(3,dep_date );
			preparedStatement.setString(4,flightno );
			ResultSet rs= preparedStatement.executeQuery();
			if(rs.next()){
				return true;
			}		}catch(SQLException e){

				myFlightLogger.error("No flight found with specifications");
			}
		return false;
	}

	@Override
	public Double firstClassFare(String flightno) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select firstseatfare from flightinfo where flightno=?")){
			preparedStatement.setString(1, flightno);	
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){
				Double firstSeatFare = resultSet.getDouble(1);
				return firstSeatFare; 
			}
		}catch(SQLException e){

		}
		return null;
	}

	@Override
	public Double bussClassFare(String flightno) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select bussseatsfare from flightinfo where flightno=?")){
			preparedStatement.setString(1, flightno);	
			ResultSet resultSet=preparedStatement.executeQuery();
			if(resultSet.next()){
				Double bussSeatFare = resultSet.getDouble(1);
				return bussSeatFare; 
			}
		}catch(SQLException e){
			myFlightLogger.error("Business class fare not selected for this flight number");

		}
		return null;
	}

	@Override
	public Integer updateFirstClassSeats(String flightno, Integer no_of_Seats)
			throws ARSException {
		try(Connection connection =DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement
						("update FlightInfo set firstseats=firstseats-? where flightno=?");){
			preparedStatement.setInt(1, no_of_Seats);
			preparedStatement.setString(2, flightno);
			int n= preparedStatement.executeUpdate();
			if(n!=0){
				myFlightLogger.info("flight updated with your specifications");

				return n;
			}
		}catch(SQLException e){
			myFlightLogger.error("Flight not updated with specifications");

		}

		return null;
	}

	@Override
	public Integer updateBussClassSeats(String flightno, Integer no_of_Seats)
			throws ARSException {
		try(Connection connection =DBConnection.getConnection();
				PreparedStatement preparedStatement=connection.prepareStatement
						("update FlightInfo set bussseats=bussseats-? where flightno=?");){
			preparedStatement.setInt(1, no_of_Seats);
			preparedStatement.setString(2, flightno);
			int n= preparedStatement.executeUpdate();
			if(n!=0){
				myFlightLogger.info("Business class seats updated");

				return n;
			}
		}catch(SQLException e){
			myFlightLogger.error("Business class seats Not updated");

		}
		return null;
	}

	@Override
	public List<Integer> occupancyDate(String flightno, Date fdate)
			throws ARSException {
		try(Connection connection =DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select firstseats,bussseats from flightinfo where dep_date=? and flightno=?")
				){
			Integer occCount=0;
			preparedStatement.setDate(1, fdate);
			
			preparedStatement.setString(2, flightno);
			ResultSet rs=preparedStatement.executeQuery();
			List<Integer> occList = new ArrayList<>();
			while(rs.next()){
				occCount++;
				
				occList.add(120-rs.getInt(1));
				occList.add(120-rs.getInt(2));
				

				
				
			}
			if(occCount!=0){
				return occList;
			}else{
				return null;
			}

		}catch(SQLException e){
			myFlightLogger.error("could not fetch details");

			//e.printStackTrace();
		}
		return null;
	}

	@Override
	public List<String> occupancyCity(String depCity, String arrCity)
			throws ARSException {
	try(
			Connection connection = DBConnection.getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("select 120-firstseats,120-bussseats,flightno from flightinfo where dep_city=?  and arr_city=?")
					){
		Integer occCount=0;
		preparedStatement.setString(1, depCity);
		preparedStatement.setString(2, arrCity);
		ResultSet resultSet = preparedStatement.executeQuery();
		List<String> occList = new ArrayList<>();
		while(resultSet.next()){
			occCount++;
			
		
			

			occList.add(resultSet.getString(1));
			occList.add(resultSet.getString(2));
			occList.add(resultSet.getString(3));
			
			
			
		}
		if(occCount!=0){
			return occList;
		}else{
			return null;
		}

	}catch(SQLException e){
		myFlightLogger.error("could not fetch details");

	}
		return null;
	}

	@Override
	public boolean isValidEmail(String email) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from bookinginfo where cust_email=?")
				
				){
			preparedStatement.setString(1,email);
			ResultSet rs= preparedStatement.executeQuery();
			if(rs.next()){
				myFlightLogger.info("flight information existed with this corresponding details");

				return true;
			}		}catch(SQLException e){
				myFlightLogger.error("could not fetch Booking Information");

			}
			
		
		return false;
	}

	@Override
	public boolean validFlight(String flightno) throws ARSException {
		try(Connection connection = DBConnection.getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("select * from FlightInfo where flightno=?")){
			preparedStatement.setString(1,flightno);
			ResultSet rs= preparedStatement.executeQuery();
			if(rs.next()){
				myFlightLogger.info("flight existed with this flight number");

				return true;
			}		}catch(SQLException e){
				myFlightLogger.error("could not fetch flight details");


			}
		return false;
	}




}
