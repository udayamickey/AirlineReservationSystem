package com.capgemini.ars.service;

import java.util.regex.Pattern;

public class Validator {
	public boolean isValidUserName(String name){
		String regex="^[A-Z][a-zA-Z]{1,16}$";
		return Pattern.matches(regex, name);
	}
	public Boolean isValidCustomerEmail(String emailId){
			
			String regex=
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"; 
						return Pattern.matches(regex,emailId); 
					
		}
	public Boolean isValidCustomerMobile(Long phoneNumber){
			 String mobile= phoneNumber.toString(phoneNumber);
			 String regex="^[1-9]{1}[0-9]{9}$";
			 return Pattern.matches(regex,mobile);
		}
	public Boolean isValidCardNumber(String cardNumber){
			 
			 String regex="^[1-9]{1}[0-9]{15}$";
			 return Pattern.matches(regex,cardNumber);
		}

}
