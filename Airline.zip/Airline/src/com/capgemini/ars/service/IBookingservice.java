package com.capgemini.ars.service;


import java.util.List;

import com.capgemini.ars.bean.BookingBean;
import com.capgemini.ars.exception.ARSException;

public interface IBookingservice {
	public BookingBean  addBookingDetails(String custEmail,Integer noOfPassengers,String classType,String creditCardInfo,String srcCity,String destCity,Double totalfare,String flightno) throws ARSException;
	public String deleteBookingDetails(Integer bookingId) throws ARSException;
public List<BookingBean> retrieveAllBookingDetails() throws ARSException;
public List<BookingBean> getBookingDetails(String custEmail) throws ARSException;
public Integer updateEmail(String Email,Integer bookingId) throws ARSException;
public abstract List<BookingBean> viewPassengerList(String flightno)throws ARSException;
public abstract boolean getBookingIdList(Integer bId)throws ARSException;
public abstract List<BookingBean> viewYourBooking(Integer BookingId)throws ARSException;
}
