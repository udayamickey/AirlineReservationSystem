package com.capgemini.ars.bean;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalTime;

public class FlightBean {
	private String flightNo;
	private String airline;
	private String dep_city;
	private String arr_city;
	private Date dep_date;
	private Date arr_date;
	private String dep_time;
	private String arr_time;
	private Integer firstSeats;
	private Double firstSeatFare;
	private Integer bussSeats;
	private Double bussSeatFare;
	
	
	public FlightBean(){
		
	}


	public FlightBean(String flightNo, String dep_time, String arr_time) {
		super();
		this.flightNo = flightNo;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
	}


	public FlightBean(String flightNo, String airline, String dep_city,
			String arr_city, Date dep_date, Date arr_date,
			String dep_time, String arr_time, Integer firstSeats,
			Double firstSeatFare, Integer bussSeats, Double bussSeatFare) {
		super();
		this.flightNo = flightNo;
		this.airline = airline;
		this.dep_city = dep_city;
		this.arr_city = arr_city;
		this.dep_date = dep_date;
		this.arr_date = arr_date;
		this.dep_time = dep_time;
		this.arr_time = arr_time;
		this.firstSeats = firstSeats;
		this.firstSeatFare = firstSeatFare;
		this.bussSeats = bussSeats;
		this.bussSeatFare = bussSeatFare;
	}


	public String getFlightNo() {
		return flightNo;
	}


	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}


	public String getAirline() {
		return airline;
	}


	public void setAirline(String airline) {
		this.airline = airline;
	}


	public String getDep_city() {
		return dep_city;
	}


	public void setDep_city(String dep_city) {
		this.dep_city = dep_city;
	}


	public String getArr_city() {
		return arr_city;
	}


	public void setArr_city(String arr_city) {
		this.arr_city = arr_city;
	}


	public Date getDep_date() {
		return dep_date;
	}


	public void setDep_date(Date dep_date) {
		this.dep_date = dep_date;
	}


	public Date getArr_date() {
		return arr_date;
	}


	public void setArr_date(Date arr_date) {
		this.arr_date = arr_date;
	}


	public String getDep_time() {
		return dep_time;
	}


	public void setDep_time(String dep_time) {
		this.dep_time = dep_time;
	}


	public String getArr_time() {
		return arr_time;
	}


	public void setArr_time(String arr_time) {
		this.arr_time = arr_time;
	}


	public Integer getFirstSeats() {
		return firstSeats;
	}


	public void setFirstSeats(Integer firstSeats) {
		this.firstSeats = firstSeats;
	}


	public Double getFirstSeatFare() {
		return firstSeatFare;
	}


	public void setFirstSeatFare(Double firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}


	public Integer getBussSeats() {
		return bussSeats;
	}


	public void setBussSeats(Integer bussSeats) {
		this.bussSeats = bussSeats;
	}


	public Double getBussSeatFare() {
		return bussSeatFare;
	}


	public void setBussSeatFare(Double bussSeatFare) {
		this.bussSeatFare = bussSeatFare;
	}


	@Override
	public String toString() {
		return "FlightDetails "
				+ "flightNo=" + flightNo + ", "
				+ "airline=" + airline
				+ ", Departure city=" + dep_city + ","
				+ " Arrival city=" + arr_city
				+ ",Departure date=" + dep_date + ", "
				+ "Arrival date=" + arr_date
				+ ",Departure time=" + dep_time + ", "
				+ "Arrival time=" + arr_time
				+ ",Number Of FirstSeats Vacant: " + firstSeats + ","
				+ " FirstSeatFare: "+ firstSeatFare + ", "
				+ "Number of bussSeats Vacant:" + bussSeats
				+ ", BussSeatFare: " + bussSeatFare;
	}
	
}