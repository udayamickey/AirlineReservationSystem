package com.capgemini.ars.exception;

public class ARSException extends Exception{
	String message;

	public ARSException() {
		super();
	}

	public ARSException(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return "ARSException [message=" + message + "]";
	}
	

}
